var aws = require('aws-sdk');
var ses = new aws.SES({region: 'ap-southeast-1'});


exports.handler = (event, context, callback) => {
    sendMail('TEST SES EMAIL FROM LAMBDA', 'Sample Body');
};

async function sendMail(subject, data) {
  const emailParams = {
        Template: "rs-template",
        Destination: {
          ToAddresses: ['kasenlow@amazon.com'],
        },
        // Message: {
        //   Body: {
        //     Text: { Data: data },
        //   },
        //   Subject: { Data: subject },
        // },
        Source: "leolin@amazon.com",
        TemplateData: "{\"name\":\"Kasen\", \"companyName\": \"AWS RealityStation\"}"
  };
      
  try {
        let key = await ses.sendTemplatedEmail(emailParams).promise();
        console.log('MAIL SENT SUCCESSFULLY!!');      
  } catch (e) {
        console.log('FAILURE IN SENDING MAIL!!', e);
      }  
  return;
}