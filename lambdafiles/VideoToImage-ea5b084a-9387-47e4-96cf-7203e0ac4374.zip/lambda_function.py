import json
import math
import cv2
import boto3
from PIL import Image
import io
from io import BytesIO
import os, tempfile, zipfile
import shutil
s3_client = boto3.client('s3')
s3_resource = boto3.resource('s3')
from subprocess import call


def lambda_handler(event, context):
    call('rm -rf /tmp/*', shell=True)
    s3_target_bucket = "aws-reality-station-processd-images" 
    dir_path = "/tmp/"
    s3_bucket = event["Records"][0]["s3"]["bucket"]["name"]
    key = event["Records"][0]["s3"]["object"]["key"]
    file_name = key
    s3_folder_name = key.split(".")[0]
    upload_path = s3_target_bucket +"/" + s3_folder_name + "/"
    
    
    print(s3_bucket)
    print(key)
    with open("/tmp/{}".format(file_name), 'wb') as data:
        s3_client.download_fileobj(s3_bucket, key, data)
    cap = cv2.VideoCapture("/tmp/{}".format(file_name))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    # for fno in range(0, total_frames):
    #     cap.set(cv2.CAP_PROP_POS_FRAMES, fno)
    #     _, frame = cap.read()
    
    print("Total Frames: " + str(total_frames))
    print("FPS: " + str(fps))
    
    #idx = 0
    allowed_frames = 65
    gap = math.ceil(total_frames / allowed_frames)
    os.mkdir('/tmp/image')
    os.mkdir('/tmp/config')
    
    
    for idx in range(0,total_frames, gap):
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        _, frame = cap.read()
        im_name = f"{idx}.jpg"
        cv2.imwrite(f"/tmp/image/{idx}.jpg",frame)
        os.chdir('/tmp/image')
        print(os.getcwd())
        print(os.listdir())
        s3_client.upload_file(f"{idx}.jpg",s3_target_bucket,s3_folder_name+"/"+im_name)
        
    
    #download xml
    s3_resource.Bucket(s3_bucket).download_file('Default.xml', '/tmp/config/Default.xml')
    
    #upload to image folder
    s3_client.upload_file('/tmp/config/Default.xml', s3_target_bucket, s3_folder_name+"/"+"Default.xml")
    
    #Create s3 Folder
    #s3_client.put_object(Bucket='flowengine-photogram-ingestionbucket917a3a3a-188tg77gpv12a', Key=s3_folder_name+'/')
    
    #zipping_files(s3_bucket, s3_folder_name)
    createZipFileStream('aws-reality-station-processd-images', s3_folder_name, s3_folder_name, 'jpg')
            
    return {
        'statusCode': 200,
        'body': json.dumps('Video to image splicing success!')
    }
    

def createZipFileStream(bucketName, bucketFilePath, jobKey, fileExt, createUrl=False):
    response = {} 
    bucket = s3_resource.Bucket(bucketName)
    filesCollection = bucket.objects.filter(Prefix=bucketFilePath).all()
    print(filesCollection)
    archive = BytesIO()

    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zip_archive:
        for file in filesCollection:
            if file.key.endswith('.' + fileExt) or file.key.endswith('.' + 'xml'):   
                with zip_archive.open(file.key, 'w') as file1:
                    print(file1)
                    file1.write(file.get()['Body'].read())

    archive.seek(0)
    s3_resource.Object('flowengine-photogram-ingestionbucket917a3a3a-188tg77gpv12a', bucketFilePath + '/' + jobKey + '.zip').upload_fileobj(archive)
    archive.close()
    
    # s3_client.upload_file('/tmp/config/Default.xml', 'flowengine-photogram-ingestionbucket917a3a3a-188tg77gpv12a', bucketFilePath+"/"+"Default.xml")

    response['fileUrl'] = None

    if createUrl is True:
        s3Client = boto3.client('s3')
        response['fileUrl'] = s3Client.generate_presigned_url('get_object', Params={'Bucket': bucketName,
                                                                                    'Key': '' + bucketFilePath + '/' + jobKey + '.zip'},
                                                              ExpiresIn=3600)

    return response
    
# def zipping_files(bucket_name, name_of_file):
#     #Download the xml file
#     key = "Default.xml"
#     local_file_name = '/tmp/image/' + key
#     s3.Bucket(bucket_name).download_file(key, local_file_name)
    
#     #zip the xml file together with the images
#     shutil.make_archive(name_of_file, 'zip', '/tmp/image')
#     print(os.listdir())
#     upload_zip(local_file_name, name_of_file)
    

# def upload_zip(zip_name, s3_3dflow_folder_name):
#     s3_3dflow_bucket = 'flowengine-photogram-ingestionbucket917a3a3a-188tg77gpv12a'
#     try:
#         s3_client.upload_file(zip_name, s3_3dflow_bucket, s3_3dflow_folder_name+"/"+zip_name)
#         print('upload success')
#     except:
#         print('upload failed')


        # for files in os.listdir("/tmp/config"):
        #     if files.endswith(".xml"):
        #         with zip_archive.open(files, 'w') as file2:
        #             file2.write(files)
        #             print("zipping default.xml")
        
        # zipObj = ZipFile(jobKey+'.zip','w')
    # with open("/tmp/config/Default.xml", "rb") as file2:
    #     archive.write(file2)