console.log('Loading function');

const aws = require('aws-sdk');
var fs = require('fs');
var path = require('path');
const obj2gltf = require("obj2gltf");

const s3 = new aws.S3({ apiVersion: '2006-03-01' });


exports.handler = async (event, context) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));

    // Get the object from the event and show its content type
    const bucket = event.Records[0].s3.bucket.name;
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    var params = {
        Bucket: bucket,
        Key: key,
    };
    // try {
    //     const { ContentType } = await s3.getObject(params).promise();
    //     console.log('CONTENT TYPE:', ContentType);
    //     return ContentType;
        
    // } catch (err) {
    //     console.log(err);
    //     const message = `Error getting object ${key} from bucket ${bucket}. Make sure they exist and your bucket is in the same region as this function.`;
    //     console.log(message);
    //     throw new Error(message);
    // }
    
    var tempFileName = path.join('/tmp', 'texturedMesh.obj');
    var tempFile = fs.createWriteStream(tempFileName);
    
    s3.getObject(params).createReadStream().pipe(tempFile);
    
    
    fs.readdir('/tmp', (err, files) => {
      files.forEach(file => {
        console.log("Output file is " + file);
      });
});


const options = {
    binary: true,
  };
  obj2gltf("/tmp/texturedMesh.obj", options).then(function (glb) {
    fs.writeFileSync("texturedMesh.glb", glb);
  });

  const fileContent = fs.readFileSync("/tmp/texturedMesh.obj")
  var params = {
    Bucket: bucket,
    Key: "texturedMesh.glb",
    Body: fileContent
  };

  s3.upload(params, function(err, data) {
      if (err) {
          throw err;
      }
      console.log(`File upload success. ${data.Location}`);
  });
    
};
